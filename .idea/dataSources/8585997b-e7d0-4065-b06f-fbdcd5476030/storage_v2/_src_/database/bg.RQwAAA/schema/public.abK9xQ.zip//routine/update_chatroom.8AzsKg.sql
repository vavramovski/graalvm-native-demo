create function update_chatroom(chatroomjson json) returns integer
    SET application_name = chatroomJson
    language plpgsql
as
$$
declare
-- variable declaration
numOfMessages integer;
begin

numOfMessages = chatroomJson ->'num_messages';

return numOfMessages;

end;
$$;

alter function update_chatroom(json) owner to postgres;

